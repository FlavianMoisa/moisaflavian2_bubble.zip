//parcurgerea sirului de la ultima bula catre prima
