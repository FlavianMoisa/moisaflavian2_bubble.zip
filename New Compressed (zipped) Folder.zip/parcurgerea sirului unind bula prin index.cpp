//parcurgerea sirului unind bula prin index
