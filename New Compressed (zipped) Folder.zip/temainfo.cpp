//optimizarea sirului de bule
#include<iostream>
int x,y;
int V[100];
using namespace std;

int main(){
    cout<<"n = ";cin>>x;
    for(int i=1;i<=x;i++){V[i]=i;}

    y=x;
    while(y){
        for(int i=1;i<=x;i++){
            if(i!=0){
                swap(V[i],V[i+1]);}
            if(i==x){
                swap(V[i+1],V[i]);}
            cout<<V[i]<<" ";}
        cout<<endl;
        y--;}

    return 1;}
